<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateQuestionStatusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('question_status', function (Blueprint $table) {
            $table->increments('question_status_id',5)->primary;            			
            $table->string('question_status_text',30);            
            $table->enum('is_active', ['1', '0']);            			         
			$table->timestamps();
			//$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('question_status');
    }
}
