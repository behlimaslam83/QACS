<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee', function (Blueprint $table) {
            $table->increments('employee_id',10)->primary;
			$table->string('employee_code',10);
            $table->string('employee_name'); 
			$table->string('employee_email',40)->unique();			
            $table->string('employee_contact_no',14);            
            $table->enum('employee_team_type', ['support', 'sales', 'hr', 'finance', 'personal']);
			$table->enum('is_active', ['1', '0']);
			$table->timestamps();
			//$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee');
    }
}
