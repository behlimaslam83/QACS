<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerQuestionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customer_questions', function (Blueprint $table) {
            $table->increments('question_id',50)->primary;
            $table->foreignId('customer_id');
            $table->foreignId('employee_id');
			$table->foreignId('question_status_id');
            $table->mediumText('question_text');            
            $table->enum('customer_satisfy_flag', ['','N', 'Y']);
            $table->mediumText('customer_satisfy_text')->nullable();			         
			$table->timestamps();
			//$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customer_questions');
    }
}
