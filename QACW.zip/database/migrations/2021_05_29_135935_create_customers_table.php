<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->increments('customer_id',10)->primary;
            $table->string('customer_name');
            $table->string('customer_email',40)->unique();
            $table->string('customer_contact_no',14);
            $table->string('customer_address');
            $table->string('customer_city',50);
            $table->string('customer_state',50);
			$table->string('customer_country',35);
            $table->enum('is_active', ['1', '0']);
			$table->timestamps();
			//$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
