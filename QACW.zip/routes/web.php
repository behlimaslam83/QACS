<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->group(['prefix' => 'api', 'middleware' => 'auth'], function () use ($router) {
  
  $router->get('customer_question/{customer_id}/{page}',  ['uses' => 'CustomerQuestionsController@showAllQuestions']);

  $router->get('customer_question_single/{question_id}/{customer_id}', ['uses' => 'CustomerQuestionsController@showOneQuestion']);

  $router->post('customer_question', ['uses' => 'CustomerQuestionsController@create']);

  $router->delete('customer_question/{question_id}/{customer_id}', ['uses' => 'CustomerQuestionsController@delete']);

  $router->put('customer_question/{question_id}/{customer_id}', ['uses' => 'CustomerQuestionsController@update']);
	
  $router->put('customer_satisfies/{question_id}', ['uses' => 'CustomerQuestionsController@customerSatisfies']);
  
  $router->put('question_status_update/{question_id}', ['uses' => 'CustomerQuestionsController@customerQuestionsStatusUpdate']);
  
  $router->put('auto_status_update',  ['uses' => 'CustomerQuestionsController@autoQuestionsStatusUpdate']);
  
  $router->post('support_question/',  ['uses' => 'CustomerQuestionsController@showAllSupportEmployeeQuestions']);
  
  $router->post('support_answers', ['uses' => 'CustomerQuestionsController@supportCreate']);
  
  $router->put('support_answers/{answer_id}', ['uses' => 'CustomerQuestionsController@supportUpdate']);
  
  $router->delete('support_answers/{answer_id}/{employee_id}', ['uses' => 'CustomerQuestionsController@supportDelete']);
  
});
