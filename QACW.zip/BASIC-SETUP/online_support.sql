-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 03, 2021 at 02:38 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_support`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_contact_no` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_state` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_country` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_contact_no`, `customer_address`, `customer_city`, `customer_state`, `customer_country`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Customer - 1', 'customer-1@customer.com', '0123456789', 'Customer address 1, Customer address 2', 'city 1', 'state 1', 'country 1', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(2, 'Customer - 2', 'customer-2@customer.com', '0123456789', 'Customer address 2, Customer address 3', 'city 2', 'state 2', 'country 2', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `customer_questions`
--

DROP TABLE IF EXISTS `customer_questions`;
CREATE TABLE IF NOT EXISTS `customer_questions` (
  `question_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `question_status_id` bigint(20) UNSIGNED NOT NULL,
  `question_text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_satisfy_flag` enum('','N','Y') COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_satisfy_text` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_questions`
--

INSERT INTO `customer_questions` (`question_id`, `customer_id`, `employee_id`, `question_status_id`, `question_text`, `customer_satisfy_flag`, `customer_satisfy_text`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 3, 'I want to now my order details', 'Y', 'Auto Status Updated', '2021-06-01 07:42:21', '2021-06-02 13:46:03'),
(2, 2, 1, 3, 'I want to now my order infomation', 'Y', 'Auto Status Updated', '2021-06-01 07:42:39', '2021-06-02 13:46:03'),
(4, 1, 2, 1, 'This is test question', '', NULL, '2021-06-01 13:03:08', '2021-06-01 13:03:08'),
(5, 1, 1, 3, 'This is test question', '', NULL, '2021-06-01 13:04:46', '2021-06-03 13:20:12');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_email` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_contact_no` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_team_type` enum('support','sales','hr','finance','personal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `employee_code`, `employee_name`, `employee_email`, `employee_contact_no`, `employee_team_type`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'E0001', 'Employee 1', 'employee-1@employee.com', '0123456789', 'support', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(2, 'E0002', 'Employee 2', 'employee-2@employee.com', '0123456789', 'support', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(3, 'E0003', 'Employee 3', 'employee-3@employee.com', '0123456789', 'sales', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_answers`
--

DROP TABLE IF EXISTS `employee_answers`;
CREATE TABLE IF NOT EXISTS `employee_answers` (
  `answers_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` bigint(20) UNSIGNED NOT NULL,
  `answers_text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`answers_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employee_answers`
--

INSERT INTO `employee_answers` (`answers_id`, `question_id`, `employee_id`, `answers_text`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'The answers text field is required 123.', '1', '2021-06-01 14:55:34', '2021-06-02 07:46:43'),
(2, 1, 2, 'The answers text field is required new update.', '1', '2021-06-02 13:43:00', '2021-06-02 13:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_05_29_133815_create_customer_questions_table', 1),
(2, '2021_05_29_134515_create_question_status_table', 1),
(3, '2021_05_29_135935_create_customers_table', 1),
(4, '2021_05_31_134537_create_employee_table', 1),
(5, '2021_05_31_134704_create_employee_answers_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `question_status`
--

DROP TABLE IF EXISTS `question_status`;
CREATE TABLE IF NOT EXISTS `question_status` (
  `question_status_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_status_text` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`question_status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `question_status`
--

INSERT INTO `question_status` (`question_status_id`, `question_status_text`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Not Answered', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(2, 'In Progress', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(3, 'Answered', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00'),
(4, 'Spam', '1', '2021-05-30 16:00:00', '2021-05-30 16:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
