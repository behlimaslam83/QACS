<?php

namespace App;


use Illuminate\Database\Eloquent\Model;


class EmployeeAnswers extends Model 
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'answers_id','question_id', 'employee_id', 'answers_text', 'is_active'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
	
	/**
     * The attributes change where condition with new table primary key
     *
     * @var string
     */
	protected $primaryKey = 'answers_id';
}
