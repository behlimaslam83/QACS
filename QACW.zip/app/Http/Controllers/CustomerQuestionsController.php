<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\CustomerQuestions;
use App\EmployeeAnswers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Mail;
class CustomerQuestionsController extends Controller
{    
    private $default_page;
	private $limit;
	private $from_email;	
	/**
     * Instantiate a new CustomerQuestionsController instance.
     */
    public function __construct()
    {
        $this->default_page = $_ENV['CUSTOM_DEFAULT_PAGE'];
		$this->limit = $_ENV['CUSTOM_PAGE_LIMIT'];
		$this->from_email = $_ENV['CUSTOM_FROM_EMAIL'];
    }
	
	/**
     * Update customer question common method.
     *
     * @param  $question_id, $customer_id, $update_question_data
     * @return Response
     */
	private function updateCustomerQuestions($question_id='', $customer_id='', $update_question_data=array())
	{
		$customer_question = CustomerQuestions::where('customer_id', $customer_id)								
								->findOrFail($question_id);
        $customer_question->update($update_question_data);
		return $customer_question;
	}
	
	/**
     * Get the customer details.
     *
     * @param  $customer_id
     * @return Response
     */
	private function getCustoemrDetails($customer_id='')
    {	
		$customer_data = DB::table('customers')            
            ->select('customers.customer_name', 'customers.customer_email', 'customers.customer_contact_no')
            ->where('customer_id', $customer_id)->get()->toArray();	
		return $customer_data;
    }
	
	/**
     * Send an e-mail reminder to the customer.
     *
     * @param  $customer_id
     * @send email
     */
    private function sendEmailReminder($customer_id)
    {   
		//Note:- this work we can do by create one email JOBS and call jobs also with SMTP server settings
		$customer = $this->getCustoemrDetails($customer_id);		
		$data = 'Your content message here!';
        Mail::send('emails.reminder', $data, function ($m) {
            $m->from($this->from_email, 'Answered reminder');
            $m->to($customer[0]->customer_email, $customer[0]->customer_name)->subject('Answered of your ask question reminder!');
        });
    }
	
	/**
     * Get all questions of customer.
     *
     * @param  customer_id, $page
     * @return Response
     */
	public function showAllQuestions($customer_id='', $page='')
    {	
		$page = ($page)?$page:$this->default_page;
		return response()->json(array('result'=>CustomerQuestions::where('customer_id', $customer_id)->limit($this->limit)->offset(($page - 1) * $this->limit)->get()));
    }
	
	/**
     * Get single question details
     *
     * @param  $question_id, $customer_id
     * @return Response
     */
    public function showOneQuestion($question_id, $customer_id='')
    {
        return response()->json(array('result'=>CustomerQuestions::where('customer_id', $customer_id)->find($question_id)));
    }
	
	/**
     * Create customer question
     *
     * @param  Request $request
     * @return Response
     */
    public function create(Request $request)
    {
        $this->validate($request, [
            'customer_id' => 'required|integer',
            'employee_id' => 'required|integer',
            'question_text' => 'required',
			'question_status_id' => 'required|integer'
        ]);		
		$customer_question = CustomerQuestions::create($request->all());
        return response()->json($customer_question, 201);
    }
	
	/**
     * Update customer question
     *
     * @param  $question_id, $customer_id, Request $request
     * @return Response
     */
    public function update($question_id='', $customer_id='', Request $request)
    {
        $this->validate($request, [            
            'employee_id' => 'required|integer',
            'question_text' => 'required',
			'question_status_id' => 'required|integer'
        ]);
		$customer_question = CustomerQuestions::where('customer_id', $customer_id)
								->findOrFail($question_id);
        $customer_question->update($request->all());
        return response()->json('Question successfully upadated', 200);
    }
	
	/**
     * Delete customer question
     *
     * @param  $question_id, $customer_id
     * @return Response
     */
    public function delete($question_id='', $customer_id='')
    {
        CustomerQuestions::where('customer_id', $customer_id)
								->findOrFail($question_id)->delete();
        return response('Question successfully deleted', 200);
    }
	
	/**
     * Answer off customer question by support team.
     *
     * @param  $question_id, Request $request
     * @return Response
     */
	public function customerSatisfies($question_id = '', Request $request)
    {
        $this->validate($request, [            
			'customer_id' => 'required|integer',
			'customer_satisfy_flag' => 'required',
			'customer_satisfy_text' => 'required'
        ]);
		$update_question_data = [];
		$update_question_data['customer_satisfy_flag'] = $request->get('customer_satisfy_flag');
		$update_question_data['customer_satisfy_text'] = $request->get('customer_satisfy_text');
		$customer_question = $this->updateCustomerQuestions($question_id, $request->get('customer_id'), $update_question_data);
		return response()->json('Question customer satisfaction response successfully upadated', 200);
    }
	
	/**
     * Status update of customer question by support team member
     *
     * @param  $question_id, Request $request
     * @return Response
     */
	public function customerQuestionsStatusUpdate($question_id = '', Request $request)
    {
        $this->validate($request, [            
			'customer_id' => 'required|integer',
			'question_status_id' => 'required|integer'
        ]);	
		$question_status_id = $request->get('question_status_id');
		$customer_id = $request->get('customer_id');
		$update_question_data['question_status_id'] = $question_status_id;		
		$customer_question = $this->updateCustomerQuestions($question_id, $customer_id, $update_question_data);
		if($question_status_id==3){
			//$this->sendEmailReminder($customer_id);
		}
		return response()->json('Question status successfully upadated', 200);
    }
	
	/**
     * Auto update statu of last 24 hours old question reply by  support team member
     *
     * @param  customer_id
     * @return Response
     */
	public function autoQuestionsStatusUpdate()
    {		
		$get_question_data = CustomerQuestions::where('question_status_id', '2')
							->where('updated_at', '<',Carbon::parse('-24 hours'))
							->get()->toArray();
		if(!empty($get_question_data)){		
			foreach($get_question_data as $row){					
				$customer_question = $this->updateCustomerQuestions($row['question_id'], $row['customer_id'], ['question_status_id'=>3, 'customer_satisfy_flag'=>'Y', 'customer_satisfy_text'=>'Auto Status Updated']);
				/* Send customer reminder email */
				//$this->sendEmailReminder($row['customer_id']);
			}
		}
		return response()->json('Last 24 hours old questions status successfully auto upadated', 200);
    }
	
	/**
     * Get all question of assign support team member with search by customer name or question title.
     *
     * @param  Request $request
     * @return Response
     */
	public function showAllSupportEmployeeQuestions(Request $request)
    { 	
		$this->validate($request, [            
			'employee_id' => 'required|integer'			
        ]);
		$page = $request->has('page') ? $request->get('page') : $this->default_page;        
		$search_key = $request->get('search_key');
		$search_value = $request->get('search_value');
		$likeCondition = [];
		$likeCondition[] = ['customer_questions.employee_id', '=', $request->get('employee_id')];		
		if($search_key!="" && $search_value!=""){			
			$field_alish = ($search_key=='question_text')?'customer_questions':'customers';		
			$likeCondition[] = [$field_alish.".".$search_key, 'LIKE', '%' . $search_value . '%'];
		}
		$get_employee_questions = DB::table('customer_questions')
            ->join('customers', 'customer_questions.customer_id', '=', 'customers.customer_id')
            ->select('customer_questions.*', 'customers.customer_name', 'customers.customer_email', 'customers.customer_contact_no')
            ->where($likeCondition)	
		//->toSql();		
		->limit($this->limit)->offset(($page - 1) * $this->limit)->get()->toArray();		
		return response()->json(array('result'=>$get_employee_questions));
    }
	
	/**
     * Send answer of customer question with update status of selected question
     *
     * @param  Request $request
     * @return Response
     */
	public function supportCreate(Request $request)
    {
		$this->validate($request, [
            'question_id' => 'required|integer',
            'employee_id' => 'required|integer',
			'customer_id' => 'required|integer',
            'answers_text' => 'required'
        ]);		
		$employee_answers = EmployeeAnswers::create($request->all());
		/* Update customer questions status after send support memeber answer */
		if($employee_answers['answers_id']){
			$customer_question = $this->updateCustomerQuestions($request->get('question_id'), $request->get('customer_id'), ['question_status_id' => 2]);
		}
        return response()->json('Answer successfully responsed to customer', 201);
    }
	
	/**
     * Update answer of customer question
     *
     * @param  $answer_id, Request $request
     * @return Response
     */
    public function supportUpdate($answer_id='', Request $request)
    {		
        $this->validate($request, [
            'question_id' => 'required|integer',
            'employee_id' => 'required|integer',
			'customer_id' => 'required|integer',
            'answers_text' => 'required'
        ]);
		$employee_answers = EmployeeAnswers::where('employee_id', $request->get('employee_id'))
								->findOrFail($answer_id);
        $employee_answers->update($request->all());
        return response()->json('Answer successfully upadated', 200);
    }
	
	/**
     * Delete answer of customer question
     *
     * @param  $answer_id, $employee_id
     * @return Response
     */
    public function supportDelete($answer_id='', $employee_id='')
    {
        EmployeeAnswers::where('employee_id', $employee_id)
								->findOrFail($answer_id)->delete();
        return response('Answer successfully deleted', 200);
    }
}
