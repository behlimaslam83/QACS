<?php

namespace App;


use Illuminate\Database\Eloquent\Model;


class CustomerQuestions extends Model 
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'question_id','customer_id', 'employee_id', 'question_status_id', 'question_text', 'customer_satisfy_flag', 'customer_satisfy_text'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
	
	/**
     * The attributes change where condition with new table primary key
     *
     * @var string
     */
	protected $primaryKey = 'question_id';
}
